
    <div class="cg-widget">
        <div class="cg-marquee">
            <marquee  class="cg-marquee-content">
                <!-- Coin Items -->
                <a href="https://www.coingecko.com/resource_redirect?locale=en&amp;route=coins/bitcoin&amp;utm_source=app.solunapower.pro&amp;utm_medium=coin_price_marquee_widget&amp;utm_content=bitcoin" target="_blank" class="cg-coin-row">
                    <div class="cg-flex cg-items-center">
                        <img src="https://assets.coingecko.com/coins/images/1/large/bitcoin.png?1696501400" alt="Bitcoin">
                        <span class="cg-bold">Bitcoin (BTC)</span>
                        <span class="cg-bold">$42,967</span>
                        <span>(-0.18%)</span>
                    </div>
                </a>
                <a href="https://www.coingecko.com/resource_redirect?locale=en&amp;route=coins/bitcoin&amp;utm_source=app.solunapower.pro&amp;utm_medium=coin_price_marquee_widget&amp;utm_content=bitcoin" target="_blank" class="cg-coin-row">
                    <div class="cg-flex cg-items-center">
                        <img src="https://assets.coingecko.com/coins/images/279/large/ethereum.png?1696501628" alt="Ethereum">
                        <span class="cg-bold">Ethereum (ETH)</span>
                        <span class="cg-bold">$42,967</span>
                        <span>(-0.18%)</span>
                    </div>
                </a>
                <a href="https://www.coingecko.com/resource_redirect?locale=en&amp;route=coins/bitcoin&amp;utm_source=app.solunapower.pro&amp;utm_medium=coin_price_marquee_widget&amp;utm_content=bitcoin" target="_blank" class="cg-coin-row">
                    <div class="cg-flex cg-items-center">
                        <img src="https://assets.coingecko.com/coins/images/2/large/litecoin.png?1696501400" alt="Litecoin">
                        <span class="cg-bold">Litecoin (LTC)</span>
                        <span class="cg-bold">$42,967</span>
                        <span>(-0.18%)</span>
                    </div>
                </a>
             <!-- Coin Items -->
             <a href="https://www.coingecko.com/resource_redirect?locale=en&amp;route=coins/bitcoin&amp;utm_source=app.solunapower.pro&amp;utm_medium=coin_price_marquee_widget&amp;utm_content=bitcoin" target="_blank" class="cg-coin-row">
                <div class="cg-flex cg-items-center">
                    <img src="https://assets.coingecko.com/coins/images/1/large/bitcoin.png?1696501400" alt="Bitcoin">
                    <span class="cg-bold">Bitcoin (BTC)</span>
                    <span class="cg-bold">$42,967</span>
                    <span>(-0.18%)</span>
                </div>
            </a>
            <a href="https://www.coingecko.com/resource_redirect?locale=en&amp;route=coins/bitcoin&amp;utm_source=app.solunapower.pro&amp;utm_medium=coin_price_marquee_widget&amp;utm_content=bitcoin" target="_blank" class="cg-coin-row">
                <div class="cg-flex cg-items-center">
                    <img src="https://assets.coingecko.com/coins/images/279/large/ethereum.png?1696501628" alt="Ethereum">
                    <span class="cg-bold">Ethereum (ETH)</span>
                    <span class="cg-bold">$42,967</span>
                    <span>(-0.18%)</span>
                </div>
            </a>
            <a href="https://www.coingecko.com/resource_redirect?locale=en&amp;route=coins/bitcoin&amp;utm_source=app.solunapower.pro&amp;utm_medium=coin_price_marquee_widget&amp;utm_content=bitcoin" target="_blank" class="cg-coin-row">
                <div class="cg-flex cg-items-center">
                    <img src="https://assets.coingecko.com/coins/images/2/large/litecoin.png?1696501400" alt="Litecoin">
                    <span class="cg-bold">Litecoin (LTC)</span>
                    <span class="cg-bold">$42,967</span>
                    <span>(-0.18%)</span>
                </div>
            </a>


                         <!-- Coin Items -->
                         <a href="https://www.coingecko.com/resource_redirect?locale=en&amp;route=coins/bitcoin&amp;utm_source=app.solunapower.pro&amp;utm_medium=coin_price_marquee_widget&amp;utm_content=bitcoin" target="_blank" class="cg-coin-row">
                            <div class="cg-flex cg-items-center">
                                <img src="https://assets.coingecko.com/coins/images/1/large/bitcoin.png?1696501400" alt="Bitcoin">
                                <span class="cg-bold">Bitcoin (BTC)</span>
                                <span class="cg-bold">$42,967</span>
                                <span>(-0.18%)</span>
                            </div>
                        </a>
                        <a href="https://www.coingecko.com/resource_redirect?locale=en&amp;route=coins/bitcoin&amp;utm_source=app.solunapower.pro&amp;utm_medium=coin_price_marquee_widget&amp;utm_content=bitcoin" target="_blank" class="cg-coin-row">
                            <div class="cg-flex cg-items-center">
                                <img src="https://assets.coingecko.com/coins/images/279/large/ethereum.png?1696501628" alt="Ethereum">
                                <span class="cg-bold">Ethereum (ETH)</span>
                                <span class="cg-bold">$42,967</span>
                                <span>(-0.18%)</span>
                            </div>
                        </a>
                        <a href="https://www.coingecko.com/resource_redirect?locale=en&amp;route=coins/bitcoin&amp;utm_source=app.solunapower.pro&amp;utm_medium=coin_price_marquee_widget&amp;utm_content=bitcoin" target="_blank" class="cg-coin-row">
                            <div class="cg-flex cg-items-center">
                                <img src="https://assets.coingecko.com/coins/images/2/large/litecoin.png?1696501400" alt="Litecoin">
                                <span class="cg-bold">Litecoin (LTC)</span>
                                <span class="cg-bold">$42,967</span>
                                <span>(-0.18%)</span>
                            </div>
                        </a>



            </marquee>
        </div>
    </div>

