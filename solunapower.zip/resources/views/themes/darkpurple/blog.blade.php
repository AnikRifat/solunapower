@extends($theme.'layouts.app')
@section('title',trans('Blogs'))

@section('content')
    @include($theme.'sections.blog')
@endsection
